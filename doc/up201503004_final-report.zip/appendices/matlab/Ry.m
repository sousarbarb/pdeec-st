function R = Ry(thy)
%RY

  R = [
     cos(thy) , 0 , sin(thy) ;
            0 , 1 ,        0 ;
    -sin(thy) , 0 , cos(thy)
  ];
end

